"""WelcomePi entrance display."""
